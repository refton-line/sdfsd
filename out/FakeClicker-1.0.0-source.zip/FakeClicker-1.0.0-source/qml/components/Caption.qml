import QtQuick
import FakeClicker

// Section label: small uppercase text with open tracking.
Label {
    color: Theme.muted
    font.family: Theme.sans
    font.pixelSize: Theme.caption
    font.weight: Font.DemiBold
    font.letterSpacing: 1
    font.capitalization: Font.AllUppercase
}
