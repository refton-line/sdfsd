import QtQuick
import FakeClicker

// Section label: small uppercase Geist with open tracking. Geist Mono's thin strokes broke up
// into stepped pixels at 10-11 px, so small text uses the proportional face throughout.
Label {
    color: Theme.muted
    font.family: Theme.sans
    font.pixelSize: Theme.caption
    font.weight: Font.DemiBold
    font.letterSpacing: 1
    font.capitalization: Font.AllUppercase
}
