import QtQuick
import FakeClicker

// Interface text, drawn by the system font rasteriser; nothing in the interface scales text, so
// distance-field rendering is not needed.
Text {
    color: Theme.ink
    font.family: Theme.sans
    font.pixelSize: Theme.body
    textFormat: Text.PlainText
    renderType: Text.NativeRendering
}
