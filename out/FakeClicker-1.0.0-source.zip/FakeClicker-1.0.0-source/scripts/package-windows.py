#!/usr/bin/env python3
"""Package an existing MinGW Windows build from Linux. Never executes PE files."""
import argparse,hashlib,json,re,shutil,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser()
p.add_argument('--qt',required=True,type=Path)
p.add_argument('--exe',required=True,type=Path)
p.add_argument('--runtime',required=True,type=Path)
p.add_argument('--output',required=True,type=Path)
p.add_argument('--receiver',type=Path)
a=p.parse_args(); out=a.output
# Refuse to package over an earlier run, so stale DLLs can never ship.
if out.exists() and any(out.iterdir()): raise SystemExit(f'{out} is not empty; remove it first')
out.mkdir(parents=True,exist_ok=True)
shutil.copy2(a.exe,out/'FakeClicker.exe')
if a.receiver: shutil.copy2(a.receiver,out/'FakeClickerReceiver.exe')
# Only the QML modules the app imports (qmlimportscanner over qml/, Basic style forced in main.cpp).
# A nested folder with its own qmldir is a separate module and ships only when listed here.
QML_MODULES={'QML','QtCore','QtQml','QtQml/Models','QtQml/WorkerScript','Qt/labs/folderlistmodel',
             'QtQuick','QtQuick/Window','QtQuick/Layouts','QtQuick/Shapes','QtQuick/Effects','QtQuick/Templates',
             'QtQuick/Controls','QtQuick/Controls/impl','QtQuick/Controls/Basic','QtQuick/Controls/Basic/impl',
             'QtQuick/Dialogs','QtQuick/Dialogs/quickimpl'}
def copy_module(src,rel):
    for item in src.iterdir():
        sub=f'{rel}/{item.name}'
        if item.is_dir():
            if item.name=='designer' or ((item/'qmldir').exists() and sub not in QML_MODULES): continue
            copy_module(item,sub)
        else:
            (out/'qml'/rel).mkdir(parents=True,exist_ok=True); shutil.copy2(item,out/'qml'/rel/item.name)
for module in sorted(m for m in QML_MODULES if '/' not in m or m=='Qt/labs/folderlistmodel'):
    copy_module(a.qt/'qml'/module,module)
for group,names in {'platforms':['qwindows.dll'],'imageformats':['qsvg.dll','qico.dll'],'iconengines':['qsvgicon.dll']}.items():
    (out/'plugins'/group).mkdir(parents=True,exist_ok=True)
    for name in names: shutil.copy2(a.qt/'plugins'/group/name,out/'plugins'/group/name)
# The compiler's own runtime wins over the copies in the Qt kit: the EXE was linked against it.
lookup={p.name.lower():p for d in [a.qt/'bin',a.runtime] for p in d.glob('*.dll')}
system=set('imagehlp authz shcore advapi32 avrt bcrypt cfgmgr32 comctl32 comdlg32 crypt32 d2d1 d3d9 d3d11 d3d12 dcomp dnsapi dwmapi dwrite dxgi dxguid gdi32 glu32 hid imm32 iphlpapi kernel32 mpr msvcrt msimg32 ncrypt netapi32 normaliz ntdll ole32 oleaut32 opengl32 powrprof propsys psapi rpcrt4 secur32 setupapi shell32 shlwapi user32 userenv usp10 uxtheme version winhttp wininet winmm winscard winspool wintrust ws2_32 wtsapi32 ucrtbase'.split())
seen=set(); missing=set(); copied=[]
for name in ['opengl32sw.dll','d3dcompiler_47.dll']:
    if name in lookup: shutil.copy2(lookup[name],out/name)
queue=list(out.rglob('*.dll'))+list(out.glob('*.exe'))
while queue:
    binary=queue.pop()
    if str(binary) in seen: continue
    seen.add(str(binary))
    result=subprocess.run(['x86_64-w64-mingw32-objdump','-p',str(binary)],capture_output=True,text=True,check=True)
    for name in re.findall(r'DLL Name:\s*(\S+)',result.stdout):
        low=name.lower()
        if low.startswith(('api-ms-','ext-ms-')) or low.removesuffix('.dll') in system: continue
        dest=out/name
        if dest.exists(): continue
        source=lookup.get(low)
        if source is None: missing.add(name); continue
        shutil.copy2(source,dest); queue.append(dest); copied.append(name)
        # Distro MinGW runtimes carry debug info (libstdc++ alone ~26 MB); Qt's kit DLLs are already stripped.
        if source.parent==a.runtime: subprocess.run(['x86_64-w64-mingw32-strip','--strip-unneeded',str(dest)],check=True)
(out/'qt.conf').write_text('[Paths]\nPrefix=.\nPlugins=plugins\nQmlImports=qml\n')
report={'PE_files_audited':len(seen),'dependency_DLLs_copied':len(copied),'unresolved_non_system_DLLs':sorted(missing),'note':'Static import audit, not proof of Windows runtime or delay-loaded system APIs.'}
meta=out.parent/out.name
(Path(f'{meta}.dependency-audit.json')).write_text(json.dumps(report,indent=2))
print(json.dumps(report))
if missing: raise SystemExit(1)
# Ship the user docs, sample profiles and the licences of everything bundled (Qt, GCC runtime, Geist).
# Developer notes (DESIGN, QA, REFERENCES) and build metadata stay out of the user package.
for name in ['START-HERE.txt','README.md','Как работает Fake Clicker.md']:
    shutil.copy2(root/name,out/name)
for folder in ['examples','licenses']: shutil.copytree(root/folder,out/folder)
sha=lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
info={'name':'Fake Clicker',
      'version':re.search(r'project\(FakeClicker VERSION (\S+)',(root/'CMakeLists.txt').read_text()).group(1),
      'target':'Windows 10/11 x64, Release, MinGW-w64 (cross-built on Linux)',
      'qt':re.search(r'QT_VERSION = (\S+)',(a.qt/'mkspecs/qconfig.pri').read_text()).group(1),
      'sha256':{f.name:sha(f) for f in sorted(out.glob('*.exe'))},
      'windows_runtime_tested':False,'details':'QA.md'}
Path(f'{meta}.build-info.json').write_text(json.dumps(info,indent=2)+'\n')
files=sorted(f for f in out.rglob('*') if f.is_file())
(out/'SHA256SUMS.txt').write_text(''.join(f'{sha(f)}  {f.relative_to(out).as_posix()}\n' for f in files),encoding='utf-8')
print(f'{len(files)} files, SHA256SUMS.txt written to {out}; build metadata next to it')
