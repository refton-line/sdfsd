Installer (NSIS 3.08+, 64-bit), one self-contained Setup.exe built from the packaged Windows folder:

  python3 scripts/package-windows.py --qt <Qt mingw_64> --exe build-cross/bin/FakeClicker.exe \
      --runtime <MinGW runtime DLLs> --output dist/FakeClicker-1.0.0-Windows-x64
  makensis -DSOURCE_DIR=<abs path to dist/FakeClicker-1.0.0-Windows-x64> -DOUT_FILE=FakeClicker-1.0.0-Setup.exe \
      "-DSIGN_CMD=<sign command> %1" installer/FakeClicker.nsi

Sign FakeClicker.exe before packaging (SHA256SUMS covers it), then sign the resulting Setup.exe.
SIGN_CMD signs the embedded uninstaller. Example with osslsigncode:
  osslsigncode sign -pkcs12 cert.pfx -pass <password> -h sha256 -n "Fake Clicker" \
      -ts http://timestamp.digicert.com -in FakeClicker.exe -out FakeClicker.signed.exe

Silent install/uninstall: Setup.exe /S, Uninstall.exe /S.
