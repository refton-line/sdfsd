; Fake Clicker — single-file Windows installer (NSIS 3.08+).
; makensis -DSOURCE_DIR=<packaged dir> -DOUT_FILE=<setup.exe> [-DSIGN_CMD="<cmd> %1"] FakeClicker.nsi
; 64-bit installer for the x64-only app; also writes to the native (non-WOW64) registry view.
Target amd64-unicode
ManifestDPIAware true
SetCompressor /SOLID lzma

!define APP_NAME "Fake Clicker"
!define APP_VERSION "1.0.0"
!define APP_EXE "FakeClicker.exe"
!define UNINST_KEY "Software\Microsoft\Windows\CurrentVersion\Uninstall\FakeClicker"
!ifndef SOURCE_DIR
  !error "SOURCE_DIR is required"
!endif
!ifndef OUT_FILE
  !define OUT_FILE "FakeClicker-${APP_VERSION}-Setup.exe"
!endif
!ifdef SIGN_CMD
  !uninstfinalize '${SIGN_CMD}'
!endif

Name "${APP_NAME}"
OutFile "${OUT_FILE}"
; Per-user install: no UAC prompt, Programs folder of the current account.
RequestExecutionLevel user
InstallDir "$LOCALAPPDATA\Programs\Fake Clicker"
InstallDirRegKey HKCU "Software\FakeClicker" "InstallDir"
BrandingText "${APP_NAME} ${APP_VERSION}"

VIProductVersion "1.0.0.0"
VIAddVersionKey /LANG=1033 "ProductName" "${APP_NAME}"
VIAddVersionKey /LANG=1033 "FileDescription" "${APP_NAME} Setup"
VIAddVersionKey /LANG=1033 "FileVersion" "${APP_VERSION}"
VIAddVersionKey /LANG=1033 "ProductVersion" "${APP_VERSION}"
VIAddVersionKey /LANG=1033 "LegalCopyright" "${APP_NAME}"

!include "MUI2.nsh"
!include "FileFunc.nsh"
!define MUI_ICON "..\assets\app.ico"
!define MUI_UNICON "..\assets\app.ico"
!define MUI_ABORTWARNING
!define MUI_FINISHPAGE_RUN "$INSTDIR\${APP_EXE}"
!define MUI_PAGE_CUSTOMFUNCTION_LEAVE DirLeave
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "Russian"
!insertmacro MUI_LANGUAGE "English"

Function .onInit
  !insertmacro MUI_LANGDLL_DISPLAY
FunctionEnd

; Always install into a dedicated "Fake Clicker" folder: reinstall and uninstall clear it recursively.
Function DirLeave
  ${GetFileName} "$INSTDIR" $0
  StrCmp $0 "Fake Clicker" +2
  StrCpy $INSTDIR "$INSTDIR\Fake Clicker"
FunctionEnd

Section "Install"
  ; The app must not be running while its files are replaced.
  nsExec::Exec 'taskkill /IM ${APP_EXE} /F'
  ; Drop files of a previous version first so no stale Qt plugins remain.
  RMDir /r "$INSTDIR"
  SetOutPath "$INSTDIR"
  File /r "${SOURCE_DIR}\*.*"
  WriteUninstaller "$INSTDIR\Uninstall.exe"

  CreateShortcut "$SMPROGRAMS\${APP_NAME}.lnk" "$INSTDIR\${APP_EXE}"
  CreateShortcut "$DESKTOP\${APP_NAME}.lnk" "$INSTDIR\${APP_EXE}"

  WriteRegStr HKCU "Software\FakeClicker" "InstallDir" "$INSTDIR"
  WriteRegStr HKCU "${UNINST_KEY}" "DisplayName" "${APP_NAME}"
  WriteRegStr HKCU "${UNINST_KEY}" "DisplayVersion" "${APP_VERSION}"
  WriteRegStr HKCU "${UNINST_KEY}" "Publisher" "${APP_NAME}"
  WriteRegStr HKCU "${UNINST_KEY}" "DisplayIcon" "$INSTDIR\${APP_EXE}"
  WriteRegStr HKCU "${UNINST_KEY}" "InstallLocation" "$INSTDIR"
  WriteRegStr HKCU "${UNINST_KEY}" "UninstallString" '"$INSTDIR\Uninstall.exe"'
  WriteRegDWORD HKCU "${UNINST_KEY}" "NoModify" 1
  WriteRegDWORD HKCU "${UNINST_KEY}" "NoRepair" 1
SectionEnd

Section "Uninstall"
  nsExec::Exec 'taskkill /IM ${APP_EXE} /F'
  Delete "$SMPROGRAMS\${APP_NAME}.lnk"
  Delete "$DESKTOP\${APP_NAME}.lnk"
  RMDir /r "$INSTDIR"
  DeleteRegKey HKCU "${UNINST_KEY}"
  DeleteRegValue HKCU "Software\FakeClicker" "InstallDir"
SectionEnd
