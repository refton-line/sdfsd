Installer (NSIS 3.08+), one self-contained Setup.exe built from the packaged Windows folder:

  python3 scripts/package-windows.py --qt <Qt mingw_64> --exe build-cross/bin/FakeClicker.exe \
      --runtime <MinGW runtime DLLs> --receiver build-cross/FakeClickerReceiver.exe --output dist
  makensis -DSOURCE_DIR=<abs path to dist> -DOUT_FILE=FakeClicker-0.8.0-Setup.exe \
      "-DSIGN_CMD=osslsigncode-wrapper %1" installer/FakeClicker.nsi

Sign FakeClicker.exe and FakeClickerReceiver.exe before packaging (SHA256SUMS covers them),
then sign the resulting Setup.exe. SIGN_CMD signs the embedded uninstaller.
