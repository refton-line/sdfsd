#include "ClickController.h"
#include "ConfigStore.h"
#include "Timing.h"
#include "ClickPlanner.h"
#include "InputSafety.h"
#include <cmath>
#include <limits>
#include "PhysicalKeyboard.h"
#include "SoundEngine.h"
#include "Storage.h"
#include <QDebug>
#include <QFile>
#include <QGuiApplication>
#include <QJsonArray>
#include <QJsonDocument>
#include <QKeyEvent>
#include <QSettings>
#include <QTemporaryDir>
#include <QDir>
#include <QFileInfo>
#include <QThread>
int main(int argc, char **argv) {
    QGuiApplication app(argc, argv);
    QTemporaryDir temp;
    qputenv("XDG_CONFIG_HOME", temp.path().toUtf8());
    app.setOrganizationName("FakeClickerTest");
    app.setApplicationName("Validation");
    QSettings().clear();
    int checks = 0;
    auto check = [&](bool ok, const char *label) {
        ++checks;
        if (!ok)
            qFatal("FAIL: %s", label);
    };
    check(InputSafety::contains(10, 20, 10, 20, 110, 120), "cursor can move at client top-left");
    check(InputSafety::contains(109, 119, 10, 20, 110, 120), "cursor can move across target");
    check(!InputSafety::contains(110, 120, 10, 20, 110, 120), "exclusive target edge");
    check(InputSafety::contains(-100, -20, -200, -100, 0, 0), "negative monitor coordinates");
    check(InputSafety::mayClick(true, true, false), "normal target movement is allowed");
    check(InputSafety::mayClick(true, false, true), "passive island does not stop clicking");
    check(!InputSafety::mayClick(false, true, false), "outside target pauses input");
    check(!InputSafety::mayClick(true, false, false), "foreign occlusion pauses input");
    check(InputSafety::mayClick(true, true, false), "re-entry resumes input");
    ClickController e;
    check(e.mode() == 0 && e.cps() == 12 && e.variance() == 1 && e.holdMs() == 0 && e.state() == "idle",
          "defaults: Legit, 12 CPS, natural variance");
    e.setCps(0);
    check(e.cps() == 12, "zero CPS rejected");
    e.setCps(-5);
    check(e.cps() == 12, "negative CPS rejected");
    e.setCps(std::numeric_limits<double>::quiet_NaN());
    check(e.cps() == 12, "NaN CPS rejected");
    e.setCps(std::numeric_limits<double>::infinity());
    check(e.cps() == 12, "infinite CPS rejected");
    e.setCps(250000);
    check(e.cps() == 250000, "custom CPS has no practical cap");
    e.setCps(12.5);
    check(e.cps() == 12.5, "fractional CPS");
    e.setMode(1);
    check(e.mode() == 1, "Blatant mode");
    e.setMode(2);
    check(e.mode() == 1, "unknown mode rejected");
    e.setVariance(3);
    check(e.variance() == 1, "variance bounds");
    e.setVariance(2);
    check(e.variance() == 2, "loose variance");
    e.setDurationSec(86400);
    e.setDurationSec(86401);
    check(e.durationSec() == 86400, "duration bounds");
    e.setMouseButton(2);
    check(e.mouseButton() == 2, "middle mouse");
    e.setMouseButton(3);
    check(e.mouseButton() == 2, "reject invalid mouse");
    check(e.applyBindings(65, 1, 66, 1), "custom Ctrl A/B");
    check(!e.applyBindings(65, 1, 65, 1), "duplicate bindings rejected");
    check(e.startKey() == 65 && e.stopKey() == 66, "failed binding preserves both");
    check(!e.applyBindings(0x7b, 0, 66, 0), "F12 rejected");
    check(!e.applyBindings(46, 3, 66, 0), "CtrlAltDel rejected");
    check(e.resetBindings(), "reset bindings");
    check(e.startKey() == 0x75 && e.stopKey() == 0x77, "reset defaults");
    e.setLaunchDelaySec(7);
    check(e.launchDelaySec() == 7, "countdown set");
    e.resetLaunchDelay();
    check(e.launchDelaySec() == e.defaultLaunchDelaySec() && e.defaultLaunchDelaySec() == 3,
          "countdown reset to default");
    check(e.startKey() == 0x75 && e.stopKey() == 0x77, "countdown reset keeps bindings");
    e.setTarget("4242", "Game");
    check(e.targetWindow() == "4242" && e.targetTitle() == "Game", "target window chosen");
    e.setTarget("", "ignored");
    check(e.targetWindow().isEmpty() && e.targetTitle().isEmpty(), "target cleared to any window");
    check(e.clicks() == 0 && e.measuredCps() < 0 && e.averageCps() < 0,
          "no fabricated measured rate");
    e.setMode(1);
    e.setCps(200);
    e.setHoldMs(5);
    check(e.holdMs() == 0 && e.error() == "holdTooLong", "Blatant hold must be shorter than the period");
    e.dismissError();
    e.setHoldMs(4);
    check(e.holdMs() == 4, "Blatant hold inside the period");
    e.setCps(1000);
    check(e.holdMs() == 0 && e.cps() == 1000, "raising the rate shortens an overlong hold");
    e.setHoldMs(1);
    check(e.holdMs() == 0, "hold equal to a 1 ms period rejected");
    e.setCps(200);
    e.setCountLimit(200);
    check(e.countLimit() == 200, "count limit");
    e.setBindingEditor(true);
    e.setCaptureCombination(true);
    QKeyEvent physical(QEvent::KeyPress, Qt::Key_K, Qt::ControlModifier | Qt::ShiftModifier);
    QObject sink;
    QCoreApplication::sendEvent(&sink, &physical);
    check(e.draftKeys() == QVariantList{75}, "Qt modifier mask cannot fabricate held Ctrl/Shift");
    check(e.pressedKeys().contains(75), "held main key is visible");
    QKeyEvent released(QEvent::KeyRelease, Qt::Key_K, Qt::ControlModifier | Qt::ShiftModifier);
    QCoreApplication::sendEvent(&sink, &released);
    check(!e.pressedKeys().contains(75), "key release clears live state");
    QKeyEvent ctrl(QEvent::KeyPress, Qt::Key_Control, Qt::ControlModifier);
    QCoreApplication::sendEvent(&sink, &ctrl);
    check(e.pressedKeys().contains(162), "Ctrl visible before a main key");
    check(e.draftKeys() == QVariantList({75, 162}), "modifier extends physical draft without replacing main key");
    QKeyEvent shift(QEvent::KeyPress, Qt::Key_Shift, Qt::ShiftModifier | Qt::ControlModifier);
    QCoreApplication::sendEvent(&sink, &shift);
    check(e.pressedKeys().contains(160) && e.pressedKeys().contains(162), "simultaneous modifiers visible");
    QKeyEvent ctrlUp(QEvent::KeyRelease, Qt::Key_Control, Qt::NoModifier);
    QCoreApplication::sendEvent(&sink, &ctrlUp);
    check(!e.pressedKeys().contains(162) && e.pressedKeys().contains(160), "independent modifier release");
    QEvent deactivate(QEvent::ApplicationDeactivate);
    QCoreApplication::sendEvent(&sink, &deactivate);
    check(e.pressedKeys().isEmpty(), "deactivate clears held keys");
    e.setCaptureCombination(false);
    QCoreApplication::sendEvent(&sink, &physical);
    check(e.draftKeys() == QVariantList{75}, "single mode ignores chord modifiers");
    e.setCaptureCombination(true);
#ifndef Q_OS_WIN
    QKeyEvent numLock(QEvent::KeyPress, Qt::Key_NumLock, Qt::NoModifier);
    const auto beforeLock = e.draftKeys();
    QCoreApplication::sendEvent(&sink, &numLock);
    check(!e.numLockOn() && e.draftKeys() == beforeLock, "Num Lock toggle never becomes candidate");
    QKeyEvent padHome(QEvent::KeyPress, Qt::Key_Home, Qt::KeypadModifier);
    QCoreApplication::sendEvent(&sink, &padHome);
    check(e.draftKeys() == beforeLock && !e.pressedKeys().contains(103), "Num off ignores keypad navigation");
    QKeyEvent home(QEvent::KeyPress, Qt::Key_Home, Qt::NoModifier);
    QCoreApplication::sendEvent(&sink, &home);
    check(e.draftKeys() == QVariantList{36}, "dedicated Home remains assignable with Num off");
    QKeyEvent lockRelease(QEvent::KeyRelease, Qt::Key_NumLock, Qt::NoModifier);
    QCoreApplication::sendEvent(&sink, &lockRelease);
    QCoreApplication::sendEvent(&sink, &numLock);
    QKeyEvent pad7(QEvent::KeyPress, Qt::Key_7, Qt::KeypadModifier);
    QCoreApplication::sendEvent(&sink, &pad7);
    check(e.numLockOn() && e.draftKeys() == QVariantList({36, 103}), "Num on captures keypad digit distinctly");
    QKeyEvent pad7Up(QEvent::KeyRelease, Qt::Key_7, Qt::KeypadModifier);
    QCoreApplication::sendEvent(&sink, &pad7Up);
    check(!e.pressedKeys().contains(103), "keypad release clears key");
    QKeyEvent bracket(QEvent::KeyPress, Qt::Key_BracketLeft, Qt::NoModifier);
    QCoreApplication::sendEvent(&sink, &bracket);
    check(e.draftKeys() == QVariantList({36, 103, 219}), "OEM punctuation maps to virtual keyboard");
#endif
    QKeyEvent aDown(QEvent::KeyPress, Qt::Key_A, Qt::NoModifier);
    QKeyEvent bDown(QEvent::KeyPress, Qt::Key_B, Qt::NoModifier);
    QCoreApplication::sendEvent(&sink, &aDown); QCoreApplication::sendEvent(&sink, &bDown);
    check(e.pressedKeys().contains(65) && e.pressedKeys().contains(66), "multiple held primary keys visible");
    const auto beforeRepeat = e.draftKeys();
    QKeyEvent repeat(QEvent::KeyPress, Qt::Key_C, Qt::NoModifier, QString(), true);
    QCoreApplication::sendEvent(&sink, &repeat);
    check(e.draftKeys() == beforeRepeat && !e.pressedKeys().contains(67), "auto-repeat does not add phantom keys");
#ifndef Q_OS_WIN
    QKeyEvent padEnter(QEvent::KeyPress, Qt::Key_Enter, Qt::KeypadModifier);
    QCoreApplication::sendEvent(&sink, &padEnter);
    check(e.pressedKeys().contains(269) && !e.pressedKeys().contains(13), "keypad Enter feedback distinct from main Enter");
    QKeyEvent rightCtrl(QEvent::KeyPress, Qt::Key_Control, Qt::ControlModifier, 105, 0, 0);
    QCoreApplication::sendEvent(&sink, &rightCtrl);
    check(e.pressedKeys().contains(163) && !e.pressedKeys().contains(162), "right Ctrl feedback has its own keycap");
#endif
    e.setBindingEditor(false);
    check(e.pressedKeys().isEmpty(), "editor close clears held keys");
    const auto closedDraft = e.draftKeys();
    QCoreApplication::sendEvent(&sink, &physical);
    check(e.draftKeys() == closedDraft, "physical capture off after editor close");
    e.setBindingEditor(true);
    e.beginBindingDraft({}, false);
    QKeyEvent tabDown(QEvent::KeyPress, Qt::Key_Tab, Qt::NoModifier);
    QKeyEvent tabUp(QEvent::KeyRelease, Qt::Key_Tab, Qt::NoModifier);
    check(QCoreApplication::sendEvent(&sink, &tabDown), "editor consumes Tab press");
    check(e.draftKeys() == QVariantList{9} && e.pressedKeys().contains(9), "physical Tab selected and held");
    QCoreApplication::sendEvent(&sink, &tabUp);
    check(e.draftKeys() == QVariantList{9} && !e.pressedKeys().contains(9), "Tab release retains draft only");
    e.setCaptureCombination(true);
    QCoreApplication::sendEvent(&sink, &shift);
    QKeyEvent backTab(QEvent::KeyPress, Qt::Key_Backtab, Qt::ShiftModifier);
    QKeyEvent backTabUp(QEvent::KeyRelease, Qt::Key_Backtab, Qt::ShiftModifier);
    QCoreApplication::sendEvent(&sink, &backTab);
    check(e.draftKeys() == QVariantList({160,9}), "Shift Backtab adds physical Shift and Tab");
    QKeyEvent tabRepeat(QEvent::KeyPress, Qt::Key_Backtab, Qt::ShiftModifier, QString(), true);
    QCoreApplication::sendEvent(&sink, &tabRepeat);
    check(e.draftKeys() == QVariantList({160,9}), "Tab auto repeat does not toggle selection");
    QCoreApplication::sendEvent(&sink, &backTabUp);
    QKeyEvent shiftUp(QEvent::KeyRelease, Qt::Key_Shift, Qt::NoModifier);
    QCoreApplication::sendEvent(&sink, &shiftUp);
    check(e.pressedKeys().isEmpty(), "Shift Tab release clears both live keys");
    QCoreApplication::sendEvent(&sink, &tabDown); QCoreApplication::sendEvent(&sink, &tabUp);
    check(e.draftKeys() == QVariantList{160}, "reselecting physical Tab removes it from chord");
    e.selectDraftKey(9);
    check(e.draftKeys() == QVariantList({160,9}), "virtual Tab uses same draft");
    check(e.applyChordSlot(false,0,e.draftKeys()), "apply physical Shift Tab chord");
    check(e.config().startChord == QList<int>({160,9}), "Tab identity preserved on apply");
    e.setBindingEditor(false); e.resetBindings();
    // Regression: apply standalone physical modifiers, not just their keycap feedback.
    for (int key : {160,161,162,163,164,165,44}) for (bool stopAction : {false,true}) {
        check(e.resetBindings(), "standalone regression fixture reset");
        e.setBindingEditor(true); e.beginBindingDraft({},false);
        e.processPhysicalKey(key,true,true); e.processPhysicalKey(key,false,true);
        check(e.draftKeys()==QVariantList{key}, "standalone modifier or PrintScreen selected");
        check(e.applyChordSlot(stopAction,0,e.draftKeys()), "standalone modifier or PrintScreen applies");
        e.setBindingEditor(false);
        const auto actual=stopAction?e.config().stopChord:e.config().startChord;
        check(actual==QList<int>{key}, "standalone binding saved in controller");
        ClickConfig roundtrip; QString why;
        check(Configuration::decode(Configuration::encode(e.config()),roundtrip,why), "standalone binding JSON roundtrip");
        check((stopAction?roundtrip.stopChord:roundtrip.startChord)==QList<int>{key}, "standalone exact side survives JSON");
        ClickController reloaded;
        check((stopAction?reloaded.config().stopChord:reloaded.config().startChord)==QList<int>{key}, "standalone exact side survives settings reload");
    }
    e.resetBindings();
    check(e.applyBindings(165,0,119,0), "AltGr standalone accepted by single-key compatibility API");
    check(e.startKey()==165 && e.config().startChord==QList<int>{165}, "AltGr standalone compatibility binding retained explicitly");
    for (int key : {160,161,162,163,164,165,44}) {
        check(e.resetBindings() && e.applyBindingSlot(false,1,key,0), "modifier/PrintScreen append compatibility route");
        check(e.startBindings()[1].toMap()["keys"].toList()==QVariantList{key}, "alternate route retains explicit physical identity");
        check(Configuration::keyName(key)!="?", "every physical modifier and PrintScreen has name");
    }
    check(Configuration::keyName(44)=="PrintScreen", "PrintScreen has stable non-question-mark label");
    e.setBindingEditor(true); e.beginBindingDraft({},false);
    QKeyEvent altOverride(QEvent::ShortcutOverride, Qt::Key_AltGr, Qt::GroupSwitchModifier);
    altOverride.ignore(); QCoreApplication::sendEvent(&sink,&altOverride);
    check(altOverride.isAccepted() && e.draftKeys().isEmpty(), "editor reserves AltGr shortcut without fabricating input");
    e.setBindingEditor(false);
    QKeyEvent ordinaryOverride(QEvent::ShortcutOverride, Qt::Key_AltGr, Qt::GroupSwitchModifier);
    ordinaryOverride.ignore(); QCoreApplication::sendEvent(&sink,&ordinaryOverride);
    check(!ordinaryOverride.isAccepted(), "closed editor does not reserve AltGr shortcut");
    e.resetBindings();
    check(PhysicalKeyboard::qtRightAlt(Qt::Key_AltGr,0,0,true), "explicit Qt AltGr accepted on Windows");
    check(PhysicalKeyboard::qtRightAlt(Qt::Key_AltGr,0,0,false), "explicit Qt AltGr accepted by native test adapter");
    check(PhysicalKeyboard::qtRightAlt(Qt::Key_Alt,165,0x38,true), "Qt VK_RMENU accepted without packed scan");
    check(PhysicalKeyboard::qtRightAlt(Qt::Key_Alt,18,0x138,true), "Qt extended right Alt scan accepted");
    check(PhysicalKeyboard::qtRightAlt(Qt::Key_Alt,18,0xe038,true), "Qt E0-prefixed right Alt scan accepted");
    check(!PhysicalKeyboard::qtRightAlt(Qt::Key_Alt,164,0x38,true), "left Alt is never inferred to be AltGr");
    check(!PhysicalKeyboard::qtRightAlt(Qt::Key_Control,163,0x11d,true), "right Ctrl is not consumed by AltGr bridge");
    check(!PhysicalKeyboard::qtRightAlt(Qt::Key_Alt,18,0,true), "ambiguous generic Alt is not forced right");
    check(!PhysicalKeyboard::qtRightAlt(Qt::Key_H,165,0x138,true), "main key with stale Alt metadata is not AltGr");
    check(!PhysicalKeyboard::qtRightAlt(Qt::Key_Alt,165,0x138,false), "Windows-native fields are not interpreted as X11 metadata");
    // A single physical AltGr may arrive through Raw Input and Qt in either order.
    // Both sources must select once, release independently, and never infer Ctrl.
    auto qtAltGr = [&](bool down, bool repeat = false) {
        QKeyEvent event(down ? QEvent::KeyPress : QEvent::KeyRelease, Qt::Key_AltGr,
                        Qt::ControlModifier | Qt::AltModifier | Qt::GroupSwitchModifier,
                        0x138, 165, 0, QString(), repeat);
        QCoreApplication::sendEvent(&sink, &event);
    };
    for (bool qtFirst : {false,true}) for (bool qtReleaseFirst : {false,true}) {
        e.setBindingEditor(false); e.setBindingEditor(true); e.beginBindingDraft({},true);
        auto raw = [&](bool down) { e.processWindowsKey(18,0x38,true,false,down,true,777); };
        if (qtFirst) { qtAltGr(true); raw(true); } else { raw(true); qtAltGr(true); }
        check(e.draftKeys()==QVariantList{165}, "two AltGr delivery sources select exactly once");
        check(e.pressedKeys()==QVariantList{165}, "AltGr modifiers never manufacture Ctrl or Alt L");
        raw(true); qtAltGr(true,true);
        check(e.draftKeys()==QVariantList{165}, "AltGr repeats do not toggle the draft");
        if (qtReleaseFirst) { qtAltGr(false); } else { raw(false); }
        check(e.pressedKeys()==QVariantList{165}, "second AltGr source retains live hold until its release");
        if (qtReleaseFirst) { raw(false); } else { qtAltGr(false); }
        check(e.pressedKeys().isEmpty() && e.draftKeys()==QVariantList{165}, "AltGr release clears feedback but retains selection");
        qtAltGr(true); qtAltGr(false);
        check(e.draftKeys().isEmpty(), "new Qt-only AltGr press toggles selection once");
        qtAltGr(true); qtAltGr(false);
        check(e.applyChordSlot(false,0,e.draftKeys()) && e.config().startChord==QList<int>{165}, "Qt AltGr selection applies as a real binding");
        e.resetBindings();
    }
    e.setBindingEditor(true); e.beginBindingDraft({},false);
    qtAltGr(true); qtAltGr(false);
    check(e.draftKeys()==QVariantList{165} && e.pressedKeys().isEmpty(), "Qt-only AltGr fallback works without raw make or break");
    e.beginBindingDraft({},true);
    e.processWindowsKey(17,0x1d,true,false,true,true,777); qtAltGr(true);
    check(e.draftKeys()==QVariantList({163,165}), "real right Ctrl survives Qt AltGr bridge");
    QCoreApplication::sendEvent(&sink,&deactivate);
    check(e.pressedKeys().isEmpty(), "deactivation clears raw and Qt AltGr holds");
    e.beginBindingDraft({},true); qtAltGr(true); qtAltGr(false);
    check(e.draftKeys()==QVariantList{165}, "AltGr recaptures after deactivation");
    e.setBindingEditor(false); const auto altGrClosedDraft=e.draftKeys();
    qtAltGr(true); qtAltGr(false);
    check(e.draftKeys()==altGrClosedDraft && e.pressedKeys().isEmpty(), "Qt bridge is editor only");
    e.resetBindings();
    // One normalization table drives both Windows Raw Input and these cases.
    const QList<QList<int>> nativeCases{
        {17,0x1d,0,162},{17,0x1d,1,163},{163,0,0,163},
        {18,0x38,0,164},{18,0x38,1,165},{165,0,0,165},
        {16,0x2a,0,160},{16,0x36,0,161},
        {38,0x48,1,38},{40,0x50,1,40},{37,0x4b,1,37},{39,0x4d,1,39},
        {45,0x52,1,45},{46,0x53,1,46},{36,0x47,1,36},{35,0x4f,1,35},
        {33,0x49,1,33},{34,0x51,1,34},
        {36,0x47,0,103},{45,0x52,0,96},{46,0x53,0,110},
        {13,0x1c,0,13},{13,0x1c,1,269},{111,0x35,1,111},
        {106,0x37,0,106},{107,0x4e,0,107},{109,0x4a,0,109},
        {65,0x23,0,72},{0,0x15,0,89},{187,0x0d,0,187},
        {144,0x45,0,144},{145,0x46,0,145},{20,0x3a,0,20},
        {44,0x37,1,44},{16,0x2a,1,0},{255,0xff,0,0}};
    for (const auto &c : nativeCases)
        check(PhysicalKeyboard::windowsKey(c[0],c[1],c[2],false)==c[3], "native identity matrix");
    const QList<QPair<int,int>> everyPlainScan{{0x1,27},{0x2,49},{0x3,50},{0x4,51},{0x5,52},{0x6,53},{0x7,54},{0x8,55},{0x9,56},{0xa,57},{0xb,48},{0xc,189},{0xd,187},{0xe,8},{0xf,9},{0x10,81},{0x11,87},{0x12,69},{0x13,82},{0x14,84},{0x15,89},{0x16,85},{0x17,73},{0x18,79},{0x19,80},{0x1a,219},{0x1b,221},{0x1c,13},{0x1e,65},{0x1f,83},{0x20,68},{0x21,70},{0x22,71},{0x23,72},{0x24,74},{0x25,75},{0x26,76},{0x27,186},{0x28,222},{0x29,192},{0x2b,220},{0x2c,90},{0x2d,88},{0x2e,67},{0x2f,86},{0x30,66},{0x31,78},{0x32,77},{0x33,188},{0x34,190},{0x35,191},{0x37,106},{0x39,32},{0x3a,20},{0x45,144},{0x46,145},{0x47,103},{0x48,104},{0x49,105},{0x4a,109},{0x4b,100},{0x4c,101},{0x4d,102},{0x4e,107},{0x4f,97},{0x50,98},{0x51,99},{0x52,96},{0x53,110},{0x56,226},{0x57,122},{0x58,123},{0x3b,112},{0x3c,113},{0x3d,114},{0x3e,115},{0x3f,116},{0x40,117},{0x41,118},{0x42,119},{0x43,120},{0x44,121}};
    for (const auto &item : everyPlainScan) check(PhysicalKeyboard::windowsKey(0,item.first,false,false)==item.second, "full printable/function/keypad scan table");
    check(PhysicalKeyboard::windowsKey(19,0x45,false,true)==19, "Pause E1");
    check(PhysicalKeyboard::windowsKey(17,0x1d,false,true)==0, "Pause fake Ctrl ignored");
    // Feed full Windows packet identities through the production controller entry point,
    // not pre-normalized VKs: truncation used to convert 0x21d into right Ctrl.
    for (bool fakeE0 : {false, true}) for (bool releaseFirst : {false, true}) {
        e.setBindingEditor(true); e.beginBindingDraft({}, true);
        auto raw = [&](int vk, unsigned scan, bool e0, bool down, quintptr device = 7) {
            e.processWindowsKey(vk,scan,e0,false,down,true,device);
        };
        if (releaseFirst) raw(163,0x21d,fakeE0,false);
        raw(163,0x21d,fakeE0,true);
        check(e.draftKeys().isEmpty() && e.pressedKeys().isEmpty(), "marked AltGr Ctrl never selects or holds either Ctrl");
        raw(18,0x38,true,true);
        check(e.draftKeys()==QVariantList{165} && e.pressedKeys()==QVariantList{165}, "AltGr raw packet selects only Alt R");
        raw(18,0x38,true,true);
        check(e.draftKeys()==QVariantList{165}, "AltGr repeat cannot toggle selected Alt");
        raw(163,0x21d,fakeE0,false); raw(18,0x38,true,false);
        check(e.pressedKeys().isEmpty() && e.draftKeys()==QVariantList{165}, "synthetic release cannot leave Ctrl or Alt held");
        e.setBindingEditor(false);
    }
    for (int ctrlSide : {162,163}) for (bool ctrlFirst : {false,true}) {
        e.setBindingEditor(true); e.beginBindingDraft({},true);
        auto control = [&](bool down) { e.processWindowsKey(17,0x1d,ctrlSide==163,false,down,true,1); };
        auto alt = [&](bool down) { e.processWindowsKey(18,0x38,true,false,down,true,2); };
        if (ctrlFirst) { control(true); alt(true); } else { alt(true); control(true); }
        check(e.pressedKeys().contains(ctrlSide) && e.pressedKeys().contains(165) && e.draftKeys().size()==2,
              "genuine Ctrl and Alt R remain separate in either order and across devices");
        e.processWindowsKey(ctrlSide,0x21d,ctrlSide==163,false,false,true,1);
        check(e.pressedKeys().contains(ctrlSide), "fake break cannot release genuine Ctrl");
        control(false); alt(false);
        check(e.pressedKeys().isEmpty(), "real Ctrl Alt release independently");
        e.setBindingEditor(false);
    }
    for (const auto &c : QList<QList<int>>{{163,0x1d,0,162},{162,0x1d,1,163},
            {163,0x38,1,165},{165,0x38,0,164},{18,0x1d,1,163},
            {17,0x38,1,165},{161,0x2a,0,160},{160,0x36,0,161},
            {17,0x21d,0,0},{163,0x21d,1,0},{18,0x138,1,0},{17,0xff,0,0}})
        check(PhysicalKeyboard::windowsKey(c[0],c[1],c[2],false)==c[3], "physical scan takes precedence; high bits are not truncated");
    check(e.resetBindings(), "prepare draft error lifecycle");
    e.dismissError(); e.setBindingEditor(true); e.beginBindingDraft({119},false);
    const auto beforeConflict = Configuration::encode(e.config());
    check(!e.applyChordSlot(false,0,{119}) && !e.draftError().isEmpty() && e.error().isEmpty(), "conflict is local to editor, never global banner");
    check(Configuration::encode(e.config())==beforeConflict, "local conflict does not mutate config");
    e.selectDraftKey(72);
    check(e.draftError().isEmpty(), "physical or virtual edit clears conflict immediately");
    check(!e.applyChordSlot(false,0,{72,72}) && !e.draftError().isEmpty(), "invalid duplicate is local");
    e.setBindingEditor(false);
    check(e.draftError().isEmpty() && e.error().isEmpty(), "cancel leaves no stuck conflict banner");
    e.setBindingEditor(true); e.beginBindingDraft({72},false);
    check(e.draftError().isEmpty() && e.applyChordSlot(false,0,{72}) && e.draftError().isEmpty(), "reopen and successful apply clear local error");
    check(!e.applyBindings(0,0,119,0) && !e.error().isEmpty(), "operational API errors remain visible");
    const bool readyBeforeDismiss=e.available(); const auto configBeforeDismiss=Configuration::encode(e.config());
    e.dismissError(); e.dismissError();
    check(e.error().isEmpty() && e.available()==readyBeforeDismiss && Configuration::encode(e.config())==configBeforeDismiss,
          "dismiss is idempotent and cannot enable unavailable input or change config");
    e.resetBindings();
    e.setBindingEditor(true);
    e.beginBindingDraft({}, true);
    e.selectDraftKey(72); e.selectDraftKey(89);
    check(e.draftKeys()==QVariantList({72,89}), "mouse-style H Y is a two-key chord");
    e.selectDraftKey(72);
    check(e.draftKeys()==QVariantList({89}), "second selection removes same key");
    e.selectDraftKey(72); e.selectDraftKey(107); e.selectDraftKey(75);
    check(e.draftKeys()==QVariantList({89,72,107}) && !e.draftError().isEmpty(), "literal plus is third key; fourth rejected");
    e.selectDraftKey(107);
    check(e.draftKeys()==QVariantList({89,72}) && e.draftError().isEmpty(), "removal clears capacity error");
    e.beginBindingDraft({}, true);
    e.processPhysicalKey(163,true,true);
    check(e.pressedKeys().contains(163) && !e.pressedKeys().contains(162) && e.draftKeys()==QVariantList({163}), "physical right Ctrl exact identity and selection");
    e.processPhysicalKey(163,false,true); e.selectDraftKey(72);
    check(e.draftKeys()==QVariantList({163,72}), "physical and mouse edits share one draft");
    e.processPhysicalKey(72,true,true); e.processPhysicalKey(72,false,true);
    check(e.draftKeys()==QVariantList({163}), "physical repeated selection removes mouse-selected key");
    e.beginBindingDraft({},true);
    e.processPhysicalKey(164,true,true);
    check(e.draftKeys()==QVariantList({164}) && !e.pressedKeys().contains(162), "left Alt never synthesizes Ctrl");
    e.processPhysicalKey(164,false,true); e.processPhysicalKey(165,true,true);
    check(e.draftKeys()==QVariantList({164,165}) && !e.pressedKeys().contains(162), "AltGr is only right Alt without phantom Ctrl");
    e.processPhysicalKey(165,false,true);
    for (int key : {37,38,39,40,45,46,36,35,33,34,13,269,106,107,109,111,186,187,188,189,190,191,192,219,220,221,222}) {
        e.beginBindingDraft({},true); e.processPhysicalKey(key,true,true);
        check(e.draftKeys()==QVariantList({key}) && e.pressedKeys().contains(key), "navigation/OEM/keypad key selects exact identity");
        e.processPhysicalKey(key,true,true);
        check(e.draftKeys()==QVariantList({key}), "repeat make does not toggle a selection");
        e.processPhysicalKey(key,false,true);
        check(!e.pressedKeys().contains(key), "each supported key releases independently");
    }
    for (int key : {96,97,98,99,100,101,102,103,104,105,110}) {
        e.beginBindingDraft({},true); e.processPhysicalKey(key,true,false);
        check(e.draftKeys().isEmpty() && !e.pressedKeys().contains(key), "Num off ignores every digit/decimal key");
        e.processPhysicalKey(key,false,false); e.processPhysicalKey(key,true,true);
        check(e.draftKeys()==QVariantList({key}), "Num on accepts each keypad identity");
        e.processPhysicalKey(key,false,true);
    }
    e.beginBindingDraft({},true); e.processPhysicalKey(72,true,true,1); e.processPhysicalKey(72,true,true,2);
    e.processPhysicalKey(72,false,true,1);
    check(e.pressedKeys().contains(72), "one keyboard release does not release another device");
    e.processPhysicalKey(72,false,true,2);
    check(!e.pressedKeys().contains(72), "all device releases clear key");
    e.setBindingEditor(false);
    check(e.applyChordSlot(false,0,{72,89}), "apply arbitrary H Y chord");
    check(e.startBindings()[0].toMap()["keys"].toList()==QVariantList({72,89}), "binding exposes explicit keys");
    check(!e.startLabel().contains('+'), "no plus separator in chord label");
    check(!e.applyChordSlot(true,0,{89,72}), "reversed-order chord conflict rejected");
    check(!e.applyChordSlot(true,0,{72}), "subset conflict rejected");
    check(!e.applyChordSlot(false,0,{72,89,75,76}), "four keys rejected atomically");
    check(!e.applyChordSlot(false,0,{72,72}), "duplicate physical key rejected");
    check(!e.applyChordSlot(false,0,{162,164,46}), "explicit Ctrl Alt Delete reserved");
    check(e.applyChordSlot(false,0,{163,72}), "side-specific modifier chord accepted");
    check(Configuration::chordMatches({72,0,{163,72}}, QSet<int>{163,72}), "right Ctrl chord matches");
    check(!Configuration::chordMatches({72,0,{163,72}}, QSet<int>{162,72}), "left Ctrl cannot match right Ctrl chord");
    check(Configuration::chordMatches({72,1}, QSet<int>{163,72}), "legacy generic Ctrl accepts right side");
    check(Configuration::chordMatches({107,0,{72,107,89}}, QSet<int>{89,72,107}), "literal keypad plus is real third required key");
    check(!Configuration::chordMatches({107,0,{72,107,89}}, QSet<int>{89,72}), "separator is not inferred as plus key");
    QString chordError; ClickConfig chordDecoded;
    check(Configuration::decode(Configuration::encode(e.config()), chordDecoded, chordError) && chordDecoded.startChord==QList<int>({163,72}), "new chord JSON roundtrip");
    auto malformedChord=Configuration::encode(e.config()); malformedChord["startChord"]=QJsonArray{163,72,75,76};
    check(!Configuration::decode(malformedChord,chordDecoded,chordError), "JSON fourth key rejected");
    malformedChord=Configuration::encode(e.config()); malformedChord["startChord"]=QJsonArray{72,72};
    check(!Configuration::decode(malformedChord,chordDecoded,chordError), "JSON duplicate chord key rejected");
    malformedChord=Configuration::encode(e.config()); malformedChord["startChord"]=QJsonArray{72.5};
    check(!Configuration::decode(malformedChord,chordDecoded,chordError), "JSON fractional chord key rejected");
    check(e.resetBindings() && e.applyChordSlot(false,0,{72,89}), "prepare global matcher");
    int starts=0, stops=0;
    QObject::connect(&e,&ClickController::shortcutActivated,&e,[&](bool stopAction){ if(stopAction) ++stops; else ++starts; });
    e.setReady(true);
    e.processPhysicalKey(72,true,true); e.processPhysicalKey(72,false,true); e.processPhysicalKey(89,true,true);
    check(starts==0, "sequential taps are not a held chord"); e.processPhysicalKey(89,false,true);
    e.processPhysicalKey(72,true,true); check(starts==0, "partial chord does not trigger");
    e.processPhysicalKey(89,true,true); check(starts==1, "all chord keys held trigger once");
    e.processPhysicalKey(89,true,true); check(starts==1, "repeat cannot retrigger global chord");
    e.processPhysicalKey(89,false,true); e.processPhysicalKey(89,true,true);
    check(starts==2, "release and repress rearm chord");
    e.processPhysicalKey(89,false,true); e.processPhysicalKey(72,false,true);
    e.processPhysicalKey(67,true,true); check(e.pressedKeys().isEmpty(), "unbound background key is not retained");
    e.processPhysicalKey(119,true,true); check(stops==1, "stop binding dispatches");
    e.processPhysicalKey(119,false,true);
    e.setBindingEditor(true); e.processPhysicalKey(119,true,true); check(stops==1, "global action disabled during editor");
    e.setBindingEditor(false);
    check(e.resetBindings() && e.applyChordSlot(false,0,{9}), "prepare global Tab binding");
    const int tabStarts = starts;
    e.processPhysicalKey(9,true,true);
    check(starts == tabStarts + 1, "global Tab dispatches");
    e.processPhysicalKey(9,true,true);
    check(starts == tabStarts + 1, "global Tab repeat ignored");
    e.processPhysicalKey(9,false,true); e.processPhysicalKey(9,true,true);
    check(starts == tabStarts + 2, "global Tab release rearms binding");
    e.processPhysicalKey(9,false,true);
    for (bool stopAction : {false,true}) for (int key : {165,44}) {
        check(e.resetBindings() && e.applyChordSlot(stopAction,0,{key}), "apply AltGr/PrintScreen for dispatch regression");
        int before = stopAction?stops:starts;
        auto packet = [&](bool down) { e.processWindowsKey(key==165?18:44,key==165?0x38:0x37,true,false,down,true,77); };
        packet(true);
        check((stopAction?stops:starts)==before+1, "applied AltGr/PrintScreen dispatches exact configured action");
        packet(true);
        check((stopAction?stops:starts)==before+1, "modifier and PrintScreen repeats do not retrigger");
        packet(false); packet(true);
        check((stopAction?stops:starts)==before+2, "AltGr/PrintScreen release rearms dispatch");
        packet(false);
    }
    e.setReady(false); e.resetBindings();
    QString err;
    ClickConfig decoded;
    auto obj = Configuration::encode(e.config());
    check(Configuration::decode(obj, decoded, err), "config roundtrip");
    obj["holdMs"] = 0.5;
    check(!Configuration::decode(obj, decoded, err), "fraction rejected");
    obj = Configuration::encode(e.config());
    obj["cps"] = QString("fast");
    check(!Configuration::decode(obj, decoded, err) && err == "notNumber:cps", "CPS type rejected");
    obj["cps"] = 0;
    check(!Configuration::decode(obj, decoded, err), "zero CPS rejected in JSON");
    obj["cps"] = 2e9;
    check(!Configuration::decode(obj, decoded, err), "CPS above one per nanosecond rejected");
    obj["cps"] = 7500.25;
    check(Configuration::decode(obj, decoded, err) && decoded.cps == 7500.25, "fractional high CPS round trip");
    obj = Configuration::encode(e.config());
    obj["mode"] = QString("turbo");
    check(!Configuration::decode(obj, decoded, err), "unknown mode rejected in JSON");
    obj["mode"] = QString("legit");
    check(Configuration::decode(obj, decoded, err) && decoded.mode == 0, "mode names decode");
    obj = Configuration::encode(e.config());
    obj["stopKey"] = QString("F8");
    check(!Configuration::decode(obj, decoded, err), "type rejected");
    obj = Configuration::encode(e.config());
    obj["unknown"] = 1;
    check(!Configuration::decode(obj, decoded, err), "unknown fields rejected");
    ConfigStore store(&e);
    check(e.applyChordSlot(false,0,{165}) && e.applyChordSlot(true,0,{44}), "AltGr and PrintScreen together for profile regression");
    check(store.saveNew("AltGr PrintScreen"), "profile with AltGr and PrintScreen saved");
    const auto specialId=store.profiles()[0].toMap()["id"].toString();
    check(e.resetBindings() && store.apply(specialId), "profile AltGr PrintScreen loads and applies");
    check(e.config().startChord==QList<int>{165} && e.config().stopChord==QList<int>{44} && e.stopLabel()=="PrintScreen", "profile keeps exact modifiers and PrintScreen name");
    check(store.remove(specialId) && e.resetBindings(), "special profile regression cleans up");
    e.setCps(200);
    check(store.saveNew("Тест200"), "save profile unicode name");
    check(store.profiles().size() == 1, "profile listed");
    auto id = store.profiles()[0].toMap()["id"].toString();
    check(store.profiles()[0].toMap()["mode"] == "blatant" && store.profiles()[0].toMap()["cps"].toDouble() == 200,
          "profile row carries mode and rate");
    e.setCps(10);
    check(store.modified(), "modified detected");
    check(store.apply(id) && e.cps() == 200, "apply profile");
    check(!store.modified(), "applied state clean");
    const QString out = temp.path() + "/export.json";
    check(store.exportFile(id, QUrl::fromLocalFile(out)), "export profile");
    check(store.importFile(QUrl::fromLocalFile(out)), "import copy");
    check(store.profiles().size() == 2, "import does not overwrite");
    check(!store.remove("../export.json"), "path traversal rejected");
    check(!store.apply("/export.json"), "absolute managed path rejected");
    check(store.rename(id, "Профиль200"), "rename profile");
    QFile bad(temp.path() + "/bad.json");
    bad.open(QIODevice::WriteOnly);
    bad.write("{broken");
    bad.close();
    check(!store.importFile(QUrl::fromLocalFile(bad.fileName())), "malformed import rejected");
    check(!store.saveNew("\n"), "invalid name rejected");
    check(store.remove(id), "delete profile");
    check(store.profiles().size() == 1, "delete updates list");
    check(Timing::rate(200, 1000000000) == 200, "measured rate200");
    check(Timing::rate(150, 1000000000) == 150, "does not substitute requested200");
    check(Timing::rate(1, 1000) < 0, "warmup no extrapolated rate");
    {
        ClickController restored;
        check(restored.cps() == 200 && restored.mode() == 1 && restored.countLimit() == 200, "new config persistence");
    }
    const auto beforeCount = store.profiles().size();
    QFile huge(temp.path() + "/huge.json");
    huge.open(QIODevice::WriteOnly);
    huge.write(QByteArray(65537, ' '));
    huge.close();
    check(!store.importFile(QUrl::fromLocalFile(huge.fileName())), "oversize import rejected");
    check(store.profiles().size() == beforeCount, "failed import does not alter profiles");
    check(!store.importFile(QUrl("https://example.com/config.json")), "remote import rejected");
    e.setCountLimit(Configuration::MaxCountLimit + 1);
    check(e.countLimit() == 200, "count overflow rejected");
    e.dismissError();
    obj = Configuration::encode(e.config());
    obj["countLimit"] = -1;
    check(!Configuration::decode(obj, decoded, err), "negative count rejected");
    check(Timing::rate(0, 1000000000) == 0, "zero sent means measured zero");
#ifndef Q_OS_WIN
    const auto link = store.directory() + "/symlink.json";
    check(QFile::link(out, link), "symlink fixture created");
    check(!store.apply("symlink.json"), "managed symlink rejected");
#endif
    check(e.applyBindingSlot(false, 1, 65, 1), "add second start binding");
    check(e.startBindings().size() == 2, "two start bindings visible");
    check(e.applyBindingSlot(true, 1, 66, 1), "add second stop binding");
    check(!e.applyBindingSlot(true, 2, 65, 1), "cross action conflict rejected");
    check(!e.applyBindingSlot(false, 2, 65, 1), "same action duplicate rejected");
    check(e.removeBinding(false, 0) && e.startKey() == 65, "removing primary promotes second");
    check(!e.removeBinding(false, 0), "at least one binding retained");
    check(e.resetBindings() && e.startBindings().size() == 1 && e.stopBindings().size() == 1,
          "reset all binding lists");
    for (int i = 1; i < 8; ++i)
        check(e.applyBindingSlot(false, i, 65 + i, 0), "append bounded binding");
    check(!e.applyBindingSlot(false, 8, 90, 0), "ninth binding rejected");
    obj = Configuration::encode(e.config());
    check(Configuration::decode(obj, decoded, err) && decoded.startExtra.size() == 7,
          "multibind JSON roundtrip");
    const QJsonObject legacy{{"intervalMs", 5},  {"durationSec", 0}, {"mouseButton", 1},
                             {"holdMs", 1},      {"countLimit", 0},  {"startKey", 0x75},
                             {"startMods", 0},   {"stopKey", 0x77},  {"stopMods", 0}};
    check(Configuration::decode(legacy, decoded, err) && decoded.launchDelay == 3 &&
              decoded.startExtra.isEmpty() && decoded.mode == 1 && decoded.cps == 200 && decoded.hold == 1,
          "legacy nine field import becomes Blatant at the same rate");
    auto legacyBad = legacy;
    legacyBad["holdMs"] = 5;
    check(!Configuration::decode(legacyBad, decoded, err), "legacy hold not shorter than interval rejected");
    legacyBad = legacy;
    legacyBad["intervalMs"] = 4;
    check(!Configuration::decode(legacyBad, decoded, err), "legacy interval below 5 ms rejected");
    auto legacyV3 = legacy;
    legacyV3["launchDelaySec"] = 4;
    legacyV3["startExtra"] = QJsonArray{QJsonObject{{"key", 0x76}, {"mods", 0}}};
    legacyV3["stopExtra"] = QJsonArray{};
    check(Configuration::decode(legacyV3, decoded, err) && decoded.launchDelay == 4 && decoded.startExtra.size() == 1,
          "legacy twelve field import");
    e.setLaunchDelaySec(7);
    check(e.launchDelaySec() == 7, "custom countdown");
    e.setLaunchDelaySec(0);
    check(e.launchDelaySec() == 7, "reject zero countdown");
    e.setLaunchDelaySec(11);
    check(e.launchDelaySec() == 7, "reject countdown overflow");
    {
        // Blatant grid
        const Planner::Grid third(3);
        check(third.at(3) == 1000000000, "fractional period lands exactly on whole seconds");
        check(third.at(3000000) == 1000000000000000LL, "no long-run drift over a million slots");
        check(third.dueThrough(-1) == 0 && third.dueThrough(0) == 1 && third.dueThrough(333333332) == 1 &&
                  third.dueThrough(333333333) == 2,
              "slot boundaries");
        const Planner::Grid fast(10000);
        check(fast.dueThrough(999999) == 10, "ten slots due in the first millisecond at 10k CPS");
        const Planner::Grid limit(Configuration::MaxCps);
        check(limit.periodNs() == 1 && limit.dueThrough(999) == 1000, "nanosecond grid at the maximum rate");
        auto b = Planner::blatantBatch(120, 1e9 / 12, true, 0);
        check(b.pairs == 1 && b.skipped == 119, "a stall at 12 CPS sends one click, not a burst");
        b = Planner::blatantBatch(10, 1e9 / 10000, true, 0);
        check(b.pairs == 10 && b.skipped == 0, "timer-resolution batching at 10k CPS");
        b = Planner::blatantBatch(1000, 1e9 / 10000, true, 0);
        check(b.pairs == Planner::MaxBatch && b.skipped == 1000 - Planner::MaxBatch, "batch capped per wake");
        b = Planner::blatantBatch(10, 1e9 / 10000, true, 3);
        check(b.pairs == 3 && b.skipped == 0, "count-limit trimming is not counted as skipped");
        b = Planner::blatantBatch(4, 1e9 / 100, false, 0);
        check(b.pairs == 1 && b.skipped == 3, "held clicks are sent one per wake");
        b = Planner::blatantBatch(0, 1e9 / 100, true, 0);
        check(b.pairs == 1 && b.skipped == 0, "a reached deadline always sends");
        bool monotonic = true;
        const Planner::Grid odd(7.3);
        for (quint64 n = 1; n < 20000; ++n)
            monotonic &= odd.at(n) > odd.at(n - 1) && odd.dueThrough(odd.at(n)) == n + 1;
        check(monotonic, "grid and due count agree for 20000 slots");
    }
    {
        // Legit humaniser
        double spread[3] = {};
        for (int variance = 0; variance < 3; ++variance) {
            Planner::Humanizer human(12, variance, 1234 + variance);
            double sum = 0, squares = 0, holdSum = 0;
            bool holdsInside = true, gapsBounded = true;
            const int n = 4000;
            for (int i = 0; i < n; ++i) {
                const auto step = human.next();
                sum += double(step.gapNs);
                squares += double(step.gapNs) * double(step.gapNs);
                holdSum += double(step.holdNs);
                holdsInside &= step.holdNs > 0 && step.holdNs < step.gapNs * 0.61;
                gapsBounded &= step.gapNs >= human.meanNs() * 0.39 && step.gapNs <= human.meanNs() * 3.91;
            }
            const double mean = sum / n, rate = 1e9 / mean;
            spread[variance] = std::sqrt(squares / n - mean * mean) / mean;
            check(std::abs(rate - 12) / 12 < 0.02, "Legit long-run average stays within 2% of target");
            check(holdsInside, "Legit hold always inside its gap");
            check(gapsBounded, "Legit gaps stay within bounds");
            check(holdSum / n > 25e6 && holdSum / n < 60e6, "Legit hold shortens with fast clicking at 12 CPS");
        }
        Planner::Humanizer relaxed(3, 1, 77);
        double relaxedHold = 0;
        for (int i = 0; i < 1000; ++i)
            relaxedHold += double(relaxed.next().holdNs);
        check(relaxedHold / 1000 > 55e6 && relaxedHold / 1000 < 95e6, "Legit hold is finger-like at relaxed rates");
        check(spread[0] > 0.04 && spread[0] < spread[1] && spread[1] < spread[2] && spread[2] < 0.5,
              "variance setting orders the rhythm spread");
        Planner::Humanizer a(16, 1, 99), b(16, 1, 99), c(16, 1, 100);
        bool same = true, different = false;
        for (int i = 0; i < 200; ++i) {
            const auto x = a.next(), y = b.next(), z = c.next();
            same &= x.gapNs == y.gapNs && x.holdNs == y.holdNs;
            different |= x.gapNs != z.gapNs;
        }
        check(same && different, "Legit sequence is seeded, not fixed");
        double warm = 0;
        for (quint64 seed = 0; seed < 64; ++seed) {
            Planner::Humanizer h(10, 1, seed);
            warm += double(h.next().gapNs);
        }
        check(warm / 64 > 1.15e8, "Legit warm-up starts slower than the target");
        Planner::Humanizer quick(1000, 2, 5);
        bool quickHolds = true;
        for (int i = 0; i < 5000; ++i) {
            const auto step = quick.next();
            quickHolds &= step.holdNs > 0 && step.holdNs < step.gapNs;
        }
        check(quickHolds, "Legit holds fit even at 1000 CPS");
    }
    store.setSearchQuery("");
    check(store.saveNew("Beta keyboard"), "save beta profile");
    QString betaId;
    for (const auto &row : store.profiles())
        if (row.toMap()["name"] == "Beta keyboard")
            betaId = row.toMap()["id"].toString();
    const auto beforeDuplicate = store.profiles().size();
    check(store.duplicate(betaId) && store.profiles().size() == beforeDuplicate + 1,
          "duplicate independent JSON");
    store.setSearchQuery("Beta keyboard");
    check(!store.profiles().isEmpty(), "case insensitive profile search");
    store.setSearchQuery("nonexistent-profile");
    check(store.profiles().isEmpty(), "empty query result");
    store.setSearchQuery("");
    check(store.profiles().size() == beforeDuplicate + 1, "search does not delete profiles");
    {
        ClickController loadedMulti;
        check(loadedMulti.startBindings().size() == 8 && loadedMulti.launchDelaySec() == 7,
              "persist multibind and countdown");
    }
    obj = Configuration::encode(e.config());
    obj["startExtra"] = QJsonArray{QJsonObject{{"key", 65.5}, {"mods", 0}}};
    check(!Configuration::decode(obj, decoded, err), "fractional extra key rejected");
    obj = Configuration::encode(e.config());
    obj["launchDelaySec"] = 2.5;
    check(!Configuration::decode(obj, decoded, err), "fractional delay rejected");
    obj = Configuration::encode(e.config());
    obj["stopExtra"] = QJsonArray{QJsonObject{{"key", 65}, {"mods", 8}}};
    check(!Configuration::decode(obj, decoded, err), "invalid modifier mask rejected");
    const auto oldDoc = QJsonDocument(QJsonObject{{"format", "obsidian-click"},
                                                  {"version", 1},
                                                  {"name", "Legacy"},
                                                  {"settings", legacy}})
                            .toJson();
    QFile oldFile(temp.path() + "/legacy.json");
    oldFile.open(QIODevice::WriteOnly);
    oldFile.write(oldDoc);
    oldFile.close();
    check(store.importFile(QUrl::fromLocalFile(oldFile.fileName())), "import original v1 envelope");
    oldFile.open(QIODevice::ReadOnly);
    check(oldFile.readAll() == oldDoc, "legacy source not rewritten");
    oldFile.close();
    // Profiles written by earlier versions under the previous format id keep loading.
    QJsonObject renamed = Configuration::encode(e.config());
    const auto cClickerDoc = QJsonDocument(QJsonObject{{"format", "c-clicker"},
                                                       {"version", 4},
                                                       {"name", "Before rename"},
                                                       {"settings", renamed}})
                                 .toJson();
    QFile cClickerFile(temp.path() + "/before-rename.json");
    cClickerFile.open(QIODevice::WriteOnly);
    cClickerFile.write(cClickerDoc);
    cClickerFile.close();
    check(store.importFile(QUrl::fromLocalFile(cClickerFile.fileName())), "import previous-format v4 profile");
    const auto unknownDoc = QJsonDocument(QJsonObject{{"format", "light-clicker"},
                                                      {"version", 3},
                                                      {"name", "Wrong version"},
                                                      {"settings", renamed}})
                                .toJson();
    QFile unknownFile(temp.path() + "/wrong-version.json");
    unknownFile.open(QIODevice::WriteOnly);
    unknownFile.write(unknownDoc);
    unknownFile.close();
    check(!store.importFile(QUrl::fromLocalFile(unknownFile.fileName())), "light-clicker accepts only v4");
    const auto lightDoc = QJsonDocument(QJsonObject{{"format", "light-clicker"},
                                                    {"version", 4},
                                                    {"name", "Light clicker profile"},
                                                    {"settings", renamed}})
                              .toJson();
    QFile lightFile(temp.path() + "/light-clicker.json");
    lightFile.open(QIODevice::WriteOnly);
    lightFile.write(lightDoc);
    lightFile.close();
    check(store.importFile(QUrl::fromLocalFile(lightFile.fileName())), "Light clicker v4 profiles still import");
    bool namedKeys = true;
    for (int k = 0; k < 512; ++k)
        if (Configuration::validKey(k) || Configuration::validChordKey(k))
            namedKeys &= Configuration::keyName(k) != "?";
    check(namedKeys, "all supported virtual keys have display labels");
    check(!store.apply("C:profile.json"), "drive-relative or NTFS stream identifier rejected");
    check(!store.remove("control\n.json"), "control character identifier rejected");
    QFile boundary(temp.path() + "/boundary.json");
    auto boundaryBytes = oldDoc;
    boundaryBytes.append(QByteArray(65536 - boundaryBytes.size(), ' '));
    boundary.open(QIODevice::WriteOnly);
    boundary.write(boundaryBytes);
    boundary.close();
    check(store.importFile(QUrl::fromLocalFile(boundary.fileName())),
          "valid JSON at exact 64KB limit");
    boundary.open(QIODevice::Append);
    boundary.write(" ");
    boundary.close();
    check(!store.importFile(QUrl::fromLocalFile(boundary.fileName())),
          "valid JSON over 64KB rejected");
    check(e.resetBindings(), "reset after multibind tests");
    check(e.applyChordSlot(false, 0, {72, 89, 163}), "prepare persistent physical triple");
    check(store.saveNew("Physical triple v3"), "save physical triple profile");
    QString tripleId;
    for (const auto &row : store.profiles())
        if (row.toMap()["name"] == "Physical triple v3")
            tripleId = row.toMap()["id"].toString();
    check(!tripleId.isEmpty(), "saved triple has managed id");
    QFile tripleFile(store.directory() + "/" + tripleId);
    check(tripleFile.open(QIODevice::ReadOnly), "read saved triple envelope");
    const auto tripleBytes = tripleFile.readAll();
    tripleFile.close();
    check(QJsonDocument::fromJson(tripleBytes).object()["version"].toInt() == 4,
          "profiles use the version 4 envelope");
    check(e.resetBindings() && store.apply(tripleId), "apply saved triple after reset");
    check(e.config().startChord == QList<int>({72, 89, 163}), "saved side-specific triple round trip");
    const QUrl tripleExport = QUrl::fromLocalFile(temp.path() + "/triple-export.json");
    check(store.exportFile(tripleId, tripleExport), "export explicit triple");
    check(store.importFile(tripleExport), "import explicit triple");
    { ClickController loadedTriple;
      check(loadedTriple.config().startChord == QList<int>({72, 89, 163}),
            "persist explicit triple through settings reload"); }
    check(e.resetBindings(), "restore defaults after triple persistence");
    for (const char *example : {"legit-12cps.json", "blatant-1000cps.json"})
        check(store.importFile(QUrl::fromLocalFile(QString(CCLICKER_SOURCE_DIR) + "/examples/" + example)),
              "bundled v4 example imports");
    // Storage: one folder (INI + configs/); a one-time copy from the ObsidianClick storage.
    {
        check(Storage::profiles() == Storage::root() + "/configs", "profiles live in the storage folder");
        check(QFileInfo(Storage::root()).fileName() == "FakeClickerTest", "storage folder is named after the app");
        QTemporaryDir old;
        QSettings legacy(old.filePath("legacy.ini"), QSettings::IniFormat);
        legacy.setValue("ui/language", "ru");
        legacy.setValue("ui/islandOverlay", false);
        legacy.sync();
        QDir().mkpath(old.filePath("configs"));
        for (const char *name : {"configs/old.json", "configs/notes.txt"}) {
            QFile file(old.filePath(name));
            check(file.open(QIODevice::WriteOnly) && file.write("{}") == 2, "legacy fixture");
        }
        QSettings fresh(old.filePath("fresh.ini"), QSettings::IniFormat);
        fresh.setValue("ui/language", "en");
        const auto copied = Storage::migrate(legacy, old.filePath("configs"), fresh, old.filePath("new/configs"));
        check(copied.keys == 1 && fresh.value("ui/language").toString() == "en" &&
                  fresh.contains("ui/islandOverlay"), "migration copies only missing keys");
        check(copied.profiles == 1 && QFile::exists(old.filePath("new/configs/old.json")) &&
                  !QFile::exists(old.filePath("new/configs/notes.txt")), "migration copies JSON profiles");
        check(QFile::exists(old.filePath("configs/old.json")) && legacy.contains("ui/language"),
              "migration keeps the old data");
        const auto again = Storage::migrate(legacy, old.filePath("configs"), fresh, old.filePath("new/configs"));
        check(again.keys == 0 && again.profiles == 0, "migration copies nothing twice");
    }
    // The saved clicker config is readable JSON text; the QJsonObject variant of older builds loads.
    {
        e.setCps(37);
        check(QSettings().value("click/config").typeId() == QMetaType::QString &&
                  QSettings().value("click/config").toString().contains("\"cps\":37"), "saved config is JSON text");
        ClickConfig older = e.config();
        older.cps = 33;
        QSettings().setValue("click/config", QVariant::fromValue(Configuration::encode(older)));
        ClickController reloaded;
        check(reloaded.cps() == 33, "config saved by older builds still loads");
        e.setCps(12);
    }
    // Sounds: clicker updates map to cues; every cue is a valid 48 kHz mono PCM WAV.
    {
        using Session = SoundEngine::Session;
        const auto cueFor = [](const Session &before, const Session &now) { return SoundEngine::sessionCues(before, now); };
        check(cueFor({"idle", 0, ""}, {"arming", 3, ""}) == QStringList{"count"}, "start ticks the countdown");
        check(cueFor({"arming", 3, ""}, {"arming", 2, ""}) == QStringList{"count"}, "each countdown second ticks");
        check(cueFor({"arming", 2, ""}, {"arming", 2, ""}).isEmpty(), "a repeated update stays silent");
        check(cueFor({"arming", 1, ""}, {"running", 0, ""}) == QStringList{"start"}, "countdown end starts");
        check(cueFor({"running", 0, ""}, {"running", 0, ""}).isEmpty(), "running samples stay silent");
        check(cueFor({"running", 0, ""}, {"stopping", 0, ""}) == QStringList{"stop"}, "stop sounds at once");
        check(cueFor({"stopping", 0, ""}, {"idle", 0, ""}).isEmpty(), "stop sounds only once");
        check(cueFor({"arming", 2, ""}, {"idle", 0, ""}) == QStringList{"stop"}, "a cancelled countdown stops");
        check(cueFor({"running", 0, ""}, {"idle", 0, ""}) == QStringList{"done"}, "a reached limit finishes");
        check(cueFor({"running", 0, ""}, {"idle", 0, "targetGone"}) == QStringList{"error"}, "an error replaces the finish");
        check(cueFor({"idle", 0, "stopFirst"}, {"idle", 0, "stopFirst"}).isEmpty(), "an unchanged error stays silent");
        for (const QString &cue : SoundEngine::cues()) {
            QFile wav(QString(CCLICKER_SOURCE_DIR) + "/assets/sounds/" + cue + ".wav");
            check(wav.open(QIODevice::ReadOnly), "every cue has a WAV");
            const qsizetype bytes = SoundEngine::pcm(wav.readAll()).size();
            check(bytes >= 2 * 48 && bytes <= 2 * 48000 * 2, "cue is 48 kHz mono 16-bit PCM, 1 ms to 2 s");
        }
        check(SoundEngine::pcm("RIFF\x04\0\0\0WAVEjunk").isEmpty(), "malformed WAV rejected");
        SoundEngine sound;
        QStringList heard;
        QObject::connect(&sound, &SoundEngine::played, [&](const QString &cue) { heard << cue; });
        sound.play("tap");
        sound.play("tap");
        sound.play("nope");
        sound.setEnabled(false);
        sound.play("select");
        sound.preview("switchOff");
        sound.setEnabled(true);
        sound.setVolume(0);
        sound.play("confirm");
        check(heard == QStringList({"tap", "switchOff"}), "muted, silent, unknown and doubled cues are not played");
        ClickController live;
        SoundEngine follower;
        QStringList sequence;
        QObject::connect(&follower, &SoundEngine::played, [&](const QString &cue) { sequence << cue; });
        follower.follow(&live);
        for (const auto &[state, countdown] : {std::pair{"arming", 2}, {"arming", 1}, {"running", 0}, {"idle", 0}}) {
            live.presentForCapture(state, 40, 12, countdown, "");
            QThread::msleep(100);
        }
        check(sequence == QStringList({"count", "count", "start", "done"}), "follow() turns clicker updates into cues");
    }
    QSettings().clear();
    qInfo() << "CONTROLLER_CONFIG_TIMING_PASS" << checks << "assertions";
}
