# Набор скиллов для Roblox / Luau

23 скилла для ИИ-агентов (формат Agent Skills, файл `SKILL.md`). Подходят для Claude Code, Codex, Cursor, Gemini CLI, GitHub Copilot и Hoplite. Скиллы универсальные и годятся для любой разработки на Roblox, в том числе для телефона с камерой.

Агент сам загружает нужный скилл по его описанию, поэтому ставить можно сразу все.

## Установка

Скопируйте **содержимое папки `skills/`** (папки `roblox-*`) в папку скиллов вашего агента:

| Агент | Для всех проектов | Только для одного проекта |
|---|---|---|
| Claude Code | `~/.claude/skills/` | `<проект>/.claude/skills/` |
| Codex, Cursor, Gemini CLI, Copilot | `~/.agents/skills/` | `<проект>/.agents/skills/` |
| Hoplite | — | `.agents/skills/` в репозитории |
| Claude.ai | Customize → Skills, каждый скилл отдельным ZIP | — |

У каждого скилла должен получиться путь вида `.../skills/roblox-input/SKILL.md`.

## Что пригодится для телефона

| Часть телефона | Скиллы |
|---|---|
| Модель телефона из деталей, материалы, скругления | `roblox-world-building` |
| Крепление к руке, телефон как Tool, поза руки | `roblox-characters-animation`, `roblox-animation` (IK, твины), `roblox-physics` (сварки) |
| Экран и приложения (SurfaceGui, ScreenGui, ViewportFrame, анимации интерфейса) | `roblox-user-interfaces`, `roblox-ui` |
| Камера: первое лицо, зум, своя камера, клавиши, колесо, щипок | `roblox-input` |
| Звук затвора, вспышка | `roblox-audio`, `roblox-vfx` |
| Качество кода | `roblox-luau`, `roblox-core`, `roblox-performance`, `roblox-code-review`, `roblox-testing` |
| Прототип в Roblox Studio | `roblox-mcp`, `roblox-rojo` |

Остальные скиллы общие: `roblox` (подсказывает, какой скилл нужен), `roblox-networking`, `roblox-datastores`, `roblox-gamepasses`, `roblox-open-cloud`, `roblox-teleport`, `roblox-npcs`.

## Важно знать

- Скиллы рассчитаны на обычную разработку в Roblox Studio, где есть сервер и клиент. Скрипт, запущенный через инжектор, работает только на клиенте. Поэтому полезны клиентские части: интерфейс, камера, ввод, анимации, эффекты. Серверные советы (DataStore, проверки на сервере, покупки) к такому скрипту не относятся.
- Ни один найденный скилл не объясняет, как показать предмет в руке от первого лица (`LocalTransparencyModifier`, viewmodel). Это придётся учесть отдельно при написании телефона.
- В скиллах есть примеры на Luau в папках `scripts/`. Это образцы кода для агента, сами они ничего не запускают.

## Откуда скиллы

| Источник | Лицензия | Что взято |
|---|---|---|
| [nonlooped/roblox-suite](https://github.com/nonlooped/roblox-suite) @ `996cae9` (21.10.2026) | MIT | все 16 скиллов: `roblox`, `roblox-core`, `roblox-networking`, `roblox-datastores`, `roblox-user-interfaces`, `roblox-animation`, `roblox-vfx`, `roblox-audio`, `roblox-gamepasses`, `roblox-open-cloud`, `roblox-teleport`, `roblox-rojo`, `roblox-mcp`, `roblox-physics`, `roblox-npcs`, `roblox-testing` |
| [EL4CTEO/roblox-skills](https://github.com/EL4CTEO/roblox-skills) @ `a7538bc` (17.10.2026) | MIT | 7 скиллов: `roblox-input`, `roblox-characters-animation`, `roblox-luau`, `roblox-ui`, `roblox-world-building`, `roblox-performance`, `roblox-code-review` |

Файлы скиллов не изменены. Тексты лицензий лежат в папке `licenses/`.

Остальные скиллы из `EL4CTEO/roblox-skills` не вошли, потому что совпадают по названию и теме со скиллами `nonlooped`. При установке в одну папку они бы перезаписали друг друга.

### Что ещё нашлось, но не вошло

- [gamedev-skills/awesome-gamedev-agent-skills](https://github.com/gamedev-skills/awesome-gamedev-agent-skills) (Apache-2.0): по Roblox там те же темы, но короче.
- [AshExplained/roblox-skills](https://github.com/AshExplained/roblox-skills) (MIT): в основном про дизайн игр, монетизацию и продвижение.
- [luumenlabs/luau-skills](https://github.com/luumenlabs/luau-skills) (MIT): Luau и Roblox, повторяет то, что уже есть в наборе.
- [Roblox/roblox-studio-agent-plugin](https://github.com/Roblox/roblox-studio-agent-plugin) (MIT, официальный): подключает агента к Roblox Studio. Полезен, если работаете с Claude или Codex на своём компьютере.
- [brockmartin/roblox-game-skill](https://github.com/brockmartin/roblox-game-skill), [sentinelcore/roblox-skills](https://github.com/sentinelcore/roblox-skills), [dig1t/skills](https://github.com/dig1t/skills): у них нет лицензии, поэтому копировать их в архив нельзя. Ставить самостоятельно по ссылкам.
